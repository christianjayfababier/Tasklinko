export interface Freelancer {
  id: string;
  name: string;
  title: string;
  description: string;
  hourlyRate: string;
  rating: number;
  reviews: number;
  completedJobs: number;
  skills: string[];
  location: string;
  imageUrl: string;
  verified: boolean;
  topRated: boolean;
}

export const mockFreelancers: Freelancer[] = [
  {
    id: '1',
    name: 'Sarah Johnson',
    title: 'Full Stack Developer',
    description: 'Expert in React, Node.js, and cloud technologies. 8+ years building scalable web applications for startups and enterprises.',
    hourlyRate: '$85/hr',
    rating: 4.9,
    reviews: 127,
    completedJobs: 243,
    skills: ['React', 'Node.js', 'TypeScript', 'AWS', 'MongoDB'],
    location: 'San Francisco, CA',
    imageUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400',
    verified: true,
    topRated: true,
  },
  {
    id: '2',
    name: 'Michael Chen',
    title: 'UI/UX Designer',
    description: 'Award-winning designer specializing in mobile apps and SaaS products. Passionate about creating delightful user experiences.',
    hourlyRate: '$70/hr',
    rating: 5.0,
    reviews: 89,
    completedJobs: 156,
    skills: ['Figma', 'UI Design', 'UX Research', 'Prototyping', 'Branding'],
    location: 'New York, NY',
    imageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400',
    verified: true,
    topRated: true,
  },
  {
    id: '3',
    name: 'Emily Rodriguez',
    title: 'Digital Marketing Strategist',
    description: 'Data-driven marketer with proven track record in SEO, PPC, and content marketing. Helped 50+ brands grow their online presence.',
    hourlyRate: '$60/hr',
    rating: 4.8,
    reviews: 102,
    completedJobs: 187,
    skills: ['SEO', 'Google Ads', 'Content Strategy', 'Analytics', 'Social Media'],
    location: 'Austin, TX',
    imageUrl: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400',
    verified: true,
    topRated: true,
  },
  {
    id: '4',
    name: 'David Kim',
    title: 'Video Editor & Motion Designer',
    description: 'Creative video editor with 6+ years experience in commercial and social media content. Specialized in motion graphics and storytelling.',
    hourlyRate: '$55/hr',
    rating: 4.9,
    reviews: 76,
    completedJobs: 134,
    skills: ['Adobe Premiere', 'After Effects', 'Motion Graphics', 'Color Grading', 'Sound Design'],
    location: 'Los Angeles, CA',
    imageUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400',
    verified: true,
    topRated: false,
  },
  {
    id: '5',
    name: 'Jessica Williams',
    title: 'Content Writer & Copywriter',
    description: 'Versatile writer creating compelling content for tech, finance, and lifestyle brands. SEO-optimized and conversion-focused writing.',
    hourlyRate: '$45/hr',
    rating: 4.7,
    reviews: 94,
    completedJobs: 312,
    skills: ['Content Writing', 'Copywriting', 'SEO', 'Blog Writing', 'Email Marketing'],
    location: 'Chicago, IL',
    imageUrl: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=400',
    verified: true,
    topRated: false,
  },
  {
    id: '6',
    name: 'Alex Thompson',
    title: 'Data Scientist',
    description: 'PhD in Machine Learning. Specializing in predictive analytics, NLP, and computer vision. Experience with Fortune 500 companies.',
    hourlyRate: '$95/hr',
    rating: 5.0,
    reviews: 54,
    completedJobs: 87,
    skills: ['Python', 'Machine Learning', 'TensorFlow', 'Data Analysis', 'SQL'],
    location: 'Seattle, WA',
    imageUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400',
    verified: true,
    topRated: true,
  },
];
