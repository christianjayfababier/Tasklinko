import { Search, Menu, X } from 'lucide-react';
import { useState } from 'react';
import { View } from '../App';

interface HeaderProps {
  currentView: View;
  onNavigate: (view: View) => void;
}

export function Header({ currentView, onNavigate }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center">
            <button 
              onClick={() => onNavigate('home')}
              className="text-2xl font-bold text-emerald-600 hover:text-emerald-700 transition-colors"
            >
              WorkHub
            </button>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <button
              onClick={() => onNavigate('browse-jobs')}
              className={`text-sm font-medium transition-colors ${
                currentView === 'browse-jobs' ? 'text-emerald-600' : 'text-gray-700 hover:text-emerald-600'
              }`}
            >
              Find Work
            </button>
            <button
              onClick={() => onNavigate('freelancers')}
              className={`text-sm font-medium transition-colors ${
                currentView === 'freelancers' ? 'text-emerald-600' : 'text-gray-700 hover:text-emerald-600'
              }`}
            >
              Find Talent
            </button>
            <button className="text-sm font-medium text-gray-700 hover:text-emerald-600 transition-colors">
              Why WorkHub
            </button>
          </nav>

          {/* Desktop Actions */}
          <div className="hidden md:flex items-center space-x-4">
            <button className="text-sm font-medium text-gray-700 hover:text-emerald-600 transition-colors">
              Log In
            </button>
            <button
              onClick={() => onNavigate('post-job')}
              className="px-4 py-2 bg-emerald-600 text-white text-sm font-medium rounded-lg hover:bg-emerald-700 transition-colors"
            >
              Post a Job
            </button>
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-gray-700"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-gray-200 bg-white">
          <div className="px-4 py-3 space-y-3">
            <button
              onClick={() => {
                onNavigate('browse-jobs');
                setMobileMenuOpen(false);
              }}
              className="block w-full text-left text-sm font-medium text-gray-700 hover:text-emerald-600"
            >
              Find Work
            </button>
            <button
              onClick={() => {
                onNavigate('freelancers');
                setMobileMenuOpen(false);
              }}
              className="block w-full text-left text-sm font-medium text-gray-700 hover:text-emerald-600"
            >
              Find Talent
            </button>
            <button className="block w-full text-left text-sm font-medium text-gray-700 hover:text-emerald-600">
              Why WorkHub
            </button>
            <hr className="border-gray-200" />
            <button className="block w-full text-left text-sm font-medium text-gray-700 hover:text-emerald-600">
              Log In
            </button>
            <button
              onClick={() => {
                onNavigate('post-job');
                setMobileMenuOpen(false);
              }}
              className="block w-full px-4 py-2 bg-emerald-600 text-white text-sm font-medium rounded-lg hover:bg-emerald-700"
            >
              Post a Job
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
