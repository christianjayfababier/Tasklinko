import { Code, Palette, Video, Megaphone, PenTool, BarChart, Globe, Smartphone } from 'lucide-react';

const categories = [
  { name: 'Web Development', icon: Code, color: 'bg-blue-100 text-blue-600' },
  { name: 'Graphic Design', icon: Palette, color: 'bg-pink-100 text-pink-600' },
  { name: 'Video & Animation', icon: Video, color: 'bg-purple-100 text-purple-600' },
  { name: 'Digital Marketing', icon: Megaphone, color: 'bg-orange-100 text-orange-600' },
  { name: 'Writing & Content', icon: PenTool, color: 'bg-green-100 text-green-600' },
  { name: 'Data Science', icon: BarChart, color: 'bg-indigo-100 text-indigo-600' },
  { name: 'Translation', icon: Globe, color: 'bg-teal-100 text-teal-600' },
  { name: 'Mobile Apps', icon: Smartphone, color: 'bg-cyan-100 text-cyan-600' },
];

export function Categories() {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Browse by Category</h2>
          <p className="text-lg text-gray-600">Find the skills you need for your next project</p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-6">
          {categories.map((category) => {
            const Icon = category.icon;
            return (
              <button
                key={category.name}
                className="group p-6 bg-white border border-gray-200 rounded-xl hover:border-emerald-500 hover:shadow-lg transition-all duration-300"
              >
                <div className={`w-12 h-12 ${category.color} rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <Icon className="w-6 h-6" />
                </div>
                <h3 className="font-semibold text-gray-900 group-hover:text-emerald-600 transition-colors">
                  {category.name}
                </h3>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
}
