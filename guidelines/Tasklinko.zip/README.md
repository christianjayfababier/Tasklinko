
  # Freelance Marketplace Website

  This is a code bundle for Freelance Marketplace Website. The original project is available at https://www.figma.com/design/up75rxoF3nrE0XGqNtmp3j/Freelance-Marketplace-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  